/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 21:59:25 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 21:59:30 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PARSING_H
# define PARSING_H

int		check_arguments(int argc, char *argv[]); // Function prototype for checking command-line arguments

int		*convert_pattern(char *str); // Function prototype for converting pattern string to integer array

void	print_puzzle_grid(int grid[4][4]); // Function prototype for printing the puzzle grid

#endif // End of parsing.h header file

