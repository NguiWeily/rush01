/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 21:59:08 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 21:59:13 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MAIN_H
# define MAIN_H

// Function prototypes

int	check_adjacent_cell(int grid[4][4], int gap, int num); // Check if the given number is adjacent to the gap position in the grid

int	puzzle_solver(int grid[4][4], int pattern[16], int gap); // Solve the puzzle by recursively placing numbers in the grid

#endif

