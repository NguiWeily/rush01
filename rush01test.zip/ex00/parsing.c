/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 22:00:59 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 22:01:04 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parsing.h"  // Include the header file for parsing functions
#include "generic.h"  // Include the header file for generic functions
#include <stdlib.h>   // Include the standard library for malloc function

int	check_arguments(int argc, char *argv[])
{
	// Check the number of arguments
	if (argc != 2)
	{
		return (1); // Return 1 if the number of arguments is incorrect
	}
	// Check the length of the argument string
	if (ft_strlen(argv[1]) != 31)
	{
		return (1); // Return 1 if the length is incorrect
	}
	return (0); // Return 0 if the arguments are valid
}

int	*convert_pattern(char *str)
{
	int	*tab;       // Declare an integer pointer
	int	i;
	int	j;

	i = 0;
	j = 0;
	tab = malloc(sizeof(int) * 16); // Allocate memory for the pattern array
	if (!tab)
	{
		return (0); // Return NULL if memory allocation fails
	}
	while (str[i] != '\0')
	{
		// Convert each numeric character to an integer and store it in the pattern array
		if (str[i] >= '0' && str[i] <= '9')
			tab[j++] = ft_atoi(str + i);
		i++;
	}
	return (tab); // Return the pattern array
}

void	print_puzzle_grid(int grid[4][4])
{
	int	i;
	int	j;

	i = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			// Print each number in the grid
			ft_putnbr(grid[i][j]);
			if (j < 3)
			{
				ft_putchar(' '); // Print a space between numbers
			}
			j++;
		}
		ft_putchar('\n'); // Print a newline character after each row
		i++;
	}
}

