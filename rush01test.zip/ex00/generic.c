/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   generic.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 22:00:10 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 22:00:14 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "generic.h" // Include the header file "generic.h"
#include <unistd.h> // Include the library for the write function

// Function to output a character to the standard output
void	ft_putchar(char c)
{
	write(1, &c, 1); // Write the character to the standard output
}

// Function to output a string to the standard output
void	ft_putstr(char *str)
{
	while (*str) // Iterate through the string until the null terminator is encountered
	{
		write(1, str++, 1); // Write each character to the standard output
	}
}

// Function to calculate the length of a string
int	ft_strlen(char *str)
{
	int	i; // Variable to store the length of the string

	i = 0; // Initialize the length to 0
	while (str[i] != '\0') // Iterate through the string until the null terminator is encountered
	{
		i++; // Increment the length
	}
	return (i); // Return the length of the string
}

// Function to convert a string to an integer
int	ft_atoi(char *str)
{
	int	i; // Variable for iterating through the string
	int	nbr; // Variable to store the converted integer
	int	sign; // Variable to track the sign of the integer

	i = 0; // Initialize the iterator to 0
	nbr = 0; // Initialize the integer value to 0
	sign = 0; // Initialize the sign to 0
	while ((str[i] >= 9 && str[i] <= 13) || str[i] == ' ') // Skip whitespace characters
		i++;
	while (str[i] == '-' || str[i] == '+') // Check for sign characters
		if (str[i++] == '-')
			sign++;
	while (str[i] >= '0' && str[i] <= '9') // Convert the remaining digits to an integer
		nbr = nbr * 10 + (str[i++] - '0');
	if (sign % 2 == 1) // Apply the sign to the integer if necessary
		return (nbr * -1);
	return (nbr); // Return the converted integer
}

// Function to output an integer to the standard output
void	ft_putnbr(int nb)
{
	unsigned int	nbr; // Variable to store the absolute value of the integer

	if (nb < 0) // Check if the integer is negative
	{
		ft_putchar('-'); // Output the negative sign
		nbr = nb * -1; // Convert the negative integer to positive
	}
	else
	{
		nbr = nb; // Assign the positive integer value
	}
	if (nbr / 10 != 0) // Check if there are more digits in the integer
	{
		ft_putnbr(nbr / 10); // Recursively call the function for the remaining digits
	}
	ft_putchar(nbr % 10 + 48); // Output the last digit of the integer as a character
}

