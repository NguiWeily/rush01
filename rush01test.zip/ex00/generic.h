/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   generic.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 21:58:49 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 23:10:28 by nwong-ch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GENERIC_H // Header guard to prevent multiple inclusions of the same header
# define GENERIC_H

// Function prototypes

void	ft_putchar(char c); // Function to output a character

void	ft_putstr(char *str); // Function to output a string

void	ft_putnbr(int nb); // Function to output an integer

int		ft_strlen(char *str); // Function to calculate the length of a string

int		ft_atoi(char *str); // Function to convert a string to an integer

#endif // End of header guard

