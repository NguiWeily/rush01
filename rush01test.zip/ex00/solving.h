/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solving.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 21:59:40 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 21:59:44 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SOLVING_H
# define SOLVING_H

/*
** Function: check_pattern
** -----------------------
** Checks if the current grid configuration violates the given pattern.
**
** grid:     the 4x4 grid of the puzzle
** gap:      the current gap position in the grid
** pattern:  the array representing the tower heights pattern
**
** returns:  1 if the pattern is violated, 0 otherwise
*/
int	check_pattern(int grid[4][4], int gap, int pattern[16]);

/*
** Function: check_col_up
** ----------------------
** Checks if the tower heights seen from the top in the given column are
** consistent with the pattern.
**
** grid:     the 4x4 grid of the puzzle
** gap:      the current gap position in the grid
** pattern:  the array representing the tower heights pattern
**
** returns:  1 if the pattern is violated, 0 otherwise
*/
int	check_col_up(int grid[4][4], int gap, int pattern[16]);

/*
** Function: check_row_right
** -------------------------
** Checks if the tower heights seen from the right in the given row are
** consistent with the pattern.
**
** grid:     the 4x4 grid of the puzzle
** gap:      the current gap position in the grid
** pattern:  the array representing the tower heights pattern
**
** returns:  1 if the pattern is violated, 0 otherwise
*/
int	check_row_right(int grid[4][4], int gap, int pattern[16]);

/*
** Function: check_col_down
** ------------------------
** Checks if the tower heights seen from the bottom in the given column are
** consistent with the pattern.
**
** grid:     the 4x4 grid of the puzzle
** gap:      the current gap position in the grid
** pattern:  the array representing the tower heights pattern
**
** returns:  1 if the pattern is violated, 0 otherwise
*/
int	check_col_down(int grid[4][4], int gap, int pattern[16]);

/*
** Function: check_row_left
** ------------------------
** Checks if the tower heights seen from the left in the given row are
** consistent with the pattern.
**
** grid:     the 4x4 grid of the puzzle
** gap:      the current gap position in the grid
** pattern:  the array representing the tower heights pattern
**
** returns:  1 if the pattern is violated, 0 otherwise
*/
int	check_row_left(int grid[4][4], int gap, int pattern[16]);

#endif

