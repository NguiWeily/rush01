/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 22:00:39 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 22:00:42 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h" // Include the header file "main.h"
#include "solving.h" // Include the header file "solving.h"
#include "parsing.h" // Include the header file "parsing.h"
#include "generic.h" // Include the header file "generic.h"
#include <stdlib.h> // Include the library for the dynamic memory allocation functions

// Function to check if a cell has adjacent cells with a certain size
int	check_adjacent_cell(int grid[4][4], int gap, int size)
{
	int	i;

	i = 0;
	while (i < gap / 4) // Check cells above the current cell
	{
		if (grid[i][gap % 4] == size)
			return (1); // Return 1 if an adjacent cell has the specified size
		i++;
	}
	i = 0;
	while (i < gap % 4) // Check cells to the left of the current cell
	{
		if (grid[gap / 4][i] == size)
			return (1); // Return 1 if an adjacent cell has the specified size
		i++;
	}
	return (0); // Return 0 if no adjacent cell has the specified size
}

// Recursive function to solve the puzzle using backtracking
int	puzzle_solver(int grid[4][4], int pattern[16], int gap)
{
	int	size;

	if (gap == 16)
		return (1); // Return 1 if the puzzle is solved (reached the end)
	size = 0;
	while (++size <= 4) // Try each size from 1 to 4
	{
		if (check_adjacent_cell(grid, gap, size) == 0) // Check if the size is valid for the current cell
		{
			grid[gap / 4][gap % 4] = size; // Assign the size to the current cell
			if (check_pattern(grid, gap, pattern) == 0) // Check if the current pattern is valid
			{
				if (puzzle_solver(grid, pattern, gap + 1) == 1) // Recursively call the function for the next cell
					return (1); // Return 1 if the puzzle is solved (reached the end)
			}
			else
			{
				grid[gap / 4][gap % 4] = 0; // Reset the current cell to 0 if the pattern is invalid
			}
		}
	}
	return (0); // Return 0 if the puzzle cannot be solved
}

int	main(int argc, char *argv[])
{
	int	grid[4][4]; // 2D array to store the puzzle grid
	int	*pattern; // Pointer to store the converted pattern array

	if (check_arguments(argc, argv) == 1) // Check if the command-line arguments are valid
	{
		ft_putstr("Error\n"); // Display an error message
		return (1); // Return 1 to indicate an error
	}
	pattern = convert_pattern(argv[1]); // Convert the pattern string to an array
	if (!pattern)
		return (1); // Return 1 if the conversion failed
	if (puzzle_solver(grid, pattern, 0) == 1) // Solve the puzzle
	{
		print_puzzle_grid(grid); // Print the solved puzzle grid
	}
	else
	{
		ft_putstr("Error\n"); // Display an error message if the puzzle cannot be solved
	}
	return (0); // Return 0 to indicate successful execution
}

