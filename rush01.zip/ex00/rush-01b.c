/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush-01b.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/01 19:16:30 by wngui             #+#    #+#             */
/*   Updated: 2023/07/01 19:16:39 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

#define MAX_SIZE 9

int	**create_grid(int size)
{
	int	**grid;
	int	i;

	grid = (int **)malloc(sizeof(int *) * size);
	if (!grid)
		return (NULL);
	i = 0;
	while (i < size)
	{
		grid[i] = (int *)malloc(sizeof(int) * size);
		if (!grid[i])
		{
			while (i >= 0)
				free(grid[i--]);
			free(grid);
			return (NULL);
		}
		i++;
	}
	return (grid);
}

void	destroy_grid(int **grid, int size)
{
	int	i;

	i = 0;
	while (i < size)
		free(grid[i++]);
	free(grid);
}

void	print_number(int num)
{
	char	c;

	c = num + '0';
	write(1, &c, 1);
}

void	print_grid(int **grid, int size)
{
	int	i;
	int	j;

	i = 0;
	while (i < size)
	{
		j = 0;
		while (j < size)
		{
			print_number(grid[i][j]);
			if (j != size - 1)
				write(1, " ", 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}

int	check_views(int **grid, int *views, int size)
{
	int	i;
	int	j;
	int	count;
	int	height;

	i = 0;
	while (i < size)
	{
		count = 0;
		height = 0;
		j = 0;
		while (j < size)
		{
			if (grid[i][j] > height)
			{
				height = grid[i][j];
				count++;
			}
			j++;
		}
		if (count != views[i])
			return (0);
		count = 0;
		height = 0;
		j = size - 1;
		while (j >= 0)
		{
			if (grid[i][j] > height)
			{
				height = grid[i][j];
				count++;
			}
			j--;
		}
		if (count != views[i + size])
			return (0);
		i++;
	}
	j = 0;
	while (j < size)
	{
		count = 0;
		height = 0;
		i = 0;
		while (i < size)
		{
			if (grid[i][j] > height)
			{
				height = grid[i][j];
				count++;
			}
			i++;
		}
		if (count != views[j + 2 * size])
			return (0);
		count = 0;
		height = 0;
		i = size - 1;
		while (i >= 0)
		{
			if (grid[i][j] > height)
			{
				height = grid[i][j];
				count++;
			}
			i--;
		}
		if (count != views[j + 3 * size])
			return (0);
		j++;
	}
	return (1);
}

int	can_place(int **grid, int row, int col, int height, int size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		if (grid[row][i] == height || grid[i][col] == height)
			return (0);
		i++;
	}
	return (1);
}

int	solve_puzzle(int **grid, int *views, int pos, int size)
{
	int	row;
	int	col;
	int	height;

	if (pos == size * size)
	{
		if (check_views(grid, views, size))
			return (1);
		return (0);
	}
	row = pos / size;
	col = pos % size;
	if (grid[row][col] != 0)
		return (solve_puzzle(grid, views, pos + 1, size));
	height = 1;
	while (height <= size)
	{
		if (can_place(grid, row, col, height, size))
		{
			grid[row][col] = height;
			if (solve_puzzle(grid, views, pos + 1, size))
				return (1);
			grid[row][col] = 0;
		}
		height++;
	}
	return (0);
}

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

void	ft_putstr(char *str)
{
	write(1, str, ft_strlen(str));
}

int	ft_atoi(char *str)
{
	int	result;
	int	i;

	result = 0;
	i = 0;
	while (str[i])
	{
		result = result * 10 + (str[i] - '0');
		i++;
	}
	return (result);
}

void	ft_error(void)
{
	ft_putstr("Error\n");
}

void	parse_input(char *str, int *views, int size)
{
	int	i;
	int	j;
	int	count;
	int	num;

	i = 0;
	j = 0;
	count = 0;
	while (str[i])
	{
		if (str[i] >= '1' && str[i] <= '9')
		{
			num = str[i] - '0';
			views[j] = num;
			count++;
			if (count > size * 4)
			{
				ft_error();
				exit(1);
			}
			j++;
		}
		i++;
	}
	if (count != size * 4)
	{
		ft_error();
		exit(1);
	}
}

int	main(int argc, char **argv)
{
	int	**grid;
	int	size;
	int	*views;

	if (argc != 3)
	{
		ft_error();
		return (1);
	}
	size = ft_atoi(argv[1]);
	if (size < 1 || size > MAX_SIZE)
	{
		ft_error();
		return (1);
	}
	views = (int *)malloc(sizeof(int) * size * 4);
	if (!views)
	{
		ft_error();
		return (1);
	}
	parse_input(argv[2], views, size);
	grid = create_grid(size);
	if (!grid)
	{
		ft_error();
		free(views);
		return (1);
	}
	if (solve_puzzle(grid, views, 0, size))
		print_grid(grid, size);
	else
		ft_error();
	destroy_grid(grid, size);
	free(views);
	return (0);
}
