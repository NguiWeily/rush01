echo "cc -Wall -Wextra -Werror -o rush-01 *.c"
cc -Wall -Wextra -Werror -o rush-01 *.c
echo "./rush-01 "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 2" | cat -e"
./rush-01 "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 2" | cat -e
echo "./rush-01 "1 2 3 2 2 2 1 3 1 4 2 2 4 1 2 2" | cat -e"
./rush-01 "1 2 3 2 2 2 1 3 1 4 2 2 4 1 2 2" | cat -e
echo "cc -Wall -Wextra -Werror -o rush-01b rush-01b.c"
#cc -Wall -Wextra -Werror -o rush-01b rush-01b.c
#echo "./rush-01b 4 "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 2" | cat -e"
#./rush-01b 4 "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 2" | cat -e
#echo "./rush-01b 4 "1 2 3 2 2 2 1 3 1 4 2 2 4 1 2 2" | cat -e"
#./rush-01b 4 "1 2 3 2 2 2 1 3 1 4 2 2 4 1 2 2" | cat -e
#echo "./rush-01b 5 "5 4 3 2 1 1 2 2 3 4 5 5 4 3 2 1 1 2 2 3 4" | cat -e"
#./rush-01b 5 "5 4 3 2 1 1 2 2 3 4 5 5 4 3 2 1 1 2 2 3 4" | cat -e
#echo "./rush-01b 6 "6 5 4 3 2 1 1 2 3 4 5 6 6 5 4 3 2 1 1 2 3 4 5 6" | cat -e"
#./rush-01b 6 "6 5 4 3 2 1 1 2 3 4 5 6 6 5 4 3 2 1 1 2 3 4 5 6" | cat -e
#echo "./rush-01b 7 "7 6 5 4 3 2 1 1 2 3 4 5 6 7 7 6 5 4 3 2 1 1 2 3 4 5 6 7" | cat -e"
#./rush-01b 7 "7 6 5 4 3 2 1 1 2 3 4 5 6 7 7 6 5 4 3 2 1 1 2 3 4 5 6 7" | cat -e
#echo "#./rush-01b 8 "8 7 6 5 4 3 2 1 1 2 3 4 5 6 7 8 8 7 6 5 4 3 2 1 1 2 3 4 5 6 7 8" | cat -e"
#./rush-01b 8 "8 7 6 5 4 3 2 1 1 2 3 4 5 6 7 8 8 7 6 5 4 3 2 1 1 2 3 4 5 6 7 8" | cat -e
#echo "./rush-01b 9 "9 8 7 6 5 4 3 2 1 1 2 3 4 5 6 7 8 9 9 8 7 6 5 4 3 2 1 1 2 3 4 5 6 7 8 9" | cat -e"
#./rush-01b 9 "9 8 7 6 5 4 3 2 1 1 2 3 4 5 6 7 8 9 9 8 7 6 5 4 3 2 1 1 2 3 4 5 6 7 8 9" | cat -e
