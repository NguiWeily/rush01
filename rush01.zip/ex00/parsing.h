/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 21:59:25 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 21:59:30 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PARSING_H
# define PARSING_H

int		check_arguments(int argc, char *argv[]);

int		*convert_pattern(char *str);

void	print_puzzle_grid(int grid[4][4]);

#endif
