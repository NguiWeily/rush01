/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush-01.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/01 16:24:10 by wngui             #+#    #+#             */
/*   Updated: 2023/07/01 16:24:14 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

#define GRID_SIZE 4

int	**create_grid(void)
{
	int	**grid;
	int	i;

	grid = (int **)malloc(sizeof(int *) * GRID_SIZE);
	if (!grid)
		return (NULL);
	i = 0;
	while (i < GRID_SIZE)
	{
		grid[i] = (int *)malloc(sizeof(int) * GRID_SIZE);
		if (!grid[i])
		{
			while (i >= 0)
				free(grid[i--]);
			free(grid);
			return (NULL);
		}
		i++;
	}
	return (grid);
}

void	destroy_grid(int **grid)
{
	int	i;

	i = 0;
	while (i < GRID_SIZE)
		free(grid[i++]);
	free(grid);
}

void	print_number(int num)
{
	char	c;

	c = num + '0';
	write(1, &c, 1);
}

void	print_grid(int **grid)
{
	int	i;
	int	j;

	i = 0;
	while (i < GRID_SIZE)
	{
		j = 0;
		while (j < GRID_SIZE)
		{
			print_number(grid[i][j]);
			if (j != GRID_SIZE - 1)
				write(1, " ", 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}

int	check_views(int **grid, int *views)
{
	int	i;
	int	j;
	int	count;
	int	height;

	i = 0;
	while (i < GRID_SIZE)
	{
		count = 0;
		height = 0;
		j = 0;
		while (j < GRID_SIZE)
		{
			if (grid[i][j] > height)
			{
				height = grid[i][j];
				count++;
			}
			j++;
		}
		if (count != views[i])
			return (0);
		count = 0;
		height = 0;
		j = GRID_SIZE - 1;
		while (j >= 0)
		{
			if (grid[i][j] > height)
			{
				height = grid[i][j];
				count++;
			}
			j--;
		}
		if (count != views[i + GRID_SIZE])
			return (0);
		i++;
	}
	j = 0;
	while (j < GRID_SIZE)
	{
		count = 0;
		height = 0;
		i = 0;
		while (i < GRID_SIZE)
		{
			if (grid[i][j] > height)
			{
				height = grid[i][j];
				count++;
			}
			i++;
		}
		if (count != views[j + 2 * GRID_SIZE])
			return (0);
		count = 0;
		height = 0;
		i = GRID_SIZE - 1;
		while (i >= 0)
		{
			if (grid[i][j] > height)
			{
				height = grid[i][j];
				count++;
			}
			i--;
		}
		if (count != views[j + 3 * GRID_SIZE])
			return (0);
		j++;
	}
	return (1);
}

int	can_place(int **grid, int row, int col, int height)
{
	int	i;

	i = 0;
	while (i < GRID_SIZE)
	{
		if (grid[row][i] == height || grid[i][col] == height)
			return (0);
		i++;
	}
	return (1);
}

int	solve_puzzle(int **grid, int *views, int pos)
{
	int	row;
	int	col;
	int	height;

	if (pos == GRID_SIZE * GRID_SIZE)
	{
		if (check_views(grid, views))
			return (1);
		return (0);
	}
	row = pos / GRID_SIZE;
	col = pos % GRID_SIZE;
	if (grid[row][col] != 0)
		return (solve_puzzle(grid, views, pos + 1));
	height = 1;
	while (height <= GRID_SIZE)
	{
		if (can_place(grid, row, col, height))
		{
			grid[row][col] = height;
			if (solve_puzzle(grid, views, pos + 1))
				return (1);
			grid[row][col] = 0;
		}
		height++;
	}
	return (0);
}

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

void	ft_putstr(char *str)
{
	write(1, str, ft_strlen(str));
}

int	ft_atoi(char *str)
{
	int	result;
	int	i;

	result = 0;
	i = 0;
	while (str[i])
	{
		result = result * 10 + (str[i] - '0');
		i++;
	}
	return (result);
}

void	ft_error(void)
{
	ft_putstr("Error\n");
}

void	parse_input(char *str, int *views)
{
	int	i;
	int	j;
	int	count;
	int	num;

	i = 0;
	j = 0;
	count = 0;
	while (str[i])
	{
		if (str[i] >= '1' && str[i] <= '4')
		{
			num = str[i] - '0';
			views[j] = num;
			count++;
			if (count > GRID_SIZE * 4)
			{
				ft_error();
				exit(1);
			}
			j++;
		}
		i++;
	}
	if (count != GRID_SIZE * 4)
	{
		ft_error();
		exit(1);
	}
}

int	main(int argc, char **argv)
{
	int	**grid;
	int	views[16];

	if (argc != 2)
	{
		ft_error();
		return (1);
	}
	parse_input(argv[1], views);
	grid = create_grid();
	if (!grid)
	{
		ft_error();
		return (1);
	}
	if (solve_puzzle(grid, views, 0))
		print_grid(grid);
	else
		ft_error();
	destroy_grid(grid);
	return (0);
}
